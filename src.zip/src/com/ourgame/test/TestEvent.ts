class TestEvent {
	public static ADD_FISH_EVENT: string = "addFishEvent";
	public static CHANGE_PATH: string = "changePath";

	public static CHANGE_MAP: string = "changeMap";
	public static CLOSE_EVENT: string = "closeEvent"
}