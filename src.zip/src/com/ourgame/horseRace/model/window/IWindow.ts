/**
 *
 * @author sxt
 *
 */
interface IWindow extends IBase {
    name: string;
    /**
     * 初始化
     */
    init(): void;
    /**
     * 销毁
     */
    destroy(): void;
}


	// public init(): void{

	// }

    // public destroy(): void{

	// }
