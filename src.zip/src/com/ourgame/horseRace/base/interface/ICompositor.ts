/**
 * 可排序的
 * @author 
 *
 */
interface ICompositor {
    sortSerial: number;
}
