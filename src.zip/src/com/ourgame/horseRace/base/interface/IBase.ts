
interface IBase {
    enter(data?: any): void;

    execute(data?: any): void;

    exit(data?: any): void;
}

// public enter(data?: any): void {

// }

// public exit(): void {

// }

// public execute(data ?: any): void {

// }