/**
 *
 * @author 
 *
 */
class MessageType {
	public constructor() {
	}
}
