/**
 * 登陆
 */
class MsgLoginReq extends BaseMessage{

	public constructor() {
		super();
	}
}