class BaseMessage {

	public constructor() {

	}

	/**
	 * 解析消息
	 */
	protected read (data:any):void{

	}
}