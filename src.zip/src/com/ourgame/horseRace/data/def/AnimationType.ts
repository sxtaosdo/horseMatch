class AnimationType {
	/**待机 */
	public static IDEL: string = "daiji";
	/**跑 */
	public static RUN: string = "pao"
	/**跨越 */
	public static JUMP: string = "kualan"
	/**落水 */
	public static DROWN: string = "luoshui"
	/**撞倒 */
	public static FALL: string = "zhanggan"
}