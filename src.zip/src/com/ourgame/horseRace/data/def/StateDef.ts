class StateDef {
	public static IDEL: number = 0;
	public static ACTIVITY: number = 1;
}