/**
 * ios接口
 * @author sxt
 *
 */
class IosInterface implements INative{
	public constructor() {
	}
	
    public closeApp(data?:any):void{
	    
	}
	
    public recharge(data?: any): void {

    }

    public scan(data?: any): void {

    }
    
    public onSocketClose(data?: any): void {
        
    }
        
    public onLoadeBegin(data?:any):void{
        
    }
    
    public onLoadeComplete(data?:any):void{
        
    }
    
    public  onLoadeError(data?:any):void{
        
    }

    public callfunction(data?: any): void {
        
    }

    public onInitComplete(data?: any): void {
        
    }
}
